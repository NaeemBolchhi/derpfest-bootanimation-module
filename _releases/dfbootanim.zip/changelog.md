### v0.1 - 2024.04.07
- Initial release
- 60fps bootanimation